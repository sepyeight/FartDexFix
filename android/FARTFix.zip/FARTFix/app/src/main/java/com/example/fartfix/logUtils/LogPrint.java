package com.example.fartfix.logUtils;

import android.util.Log;

public class LogPrint {
    private static boolean verbose = true;

    public static void logd(String tag, String msg) {
        if (verbose) {
            Log.d(tag, msg);
        }
    }
}
