package com.example.fartfix.tools;

import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import com.example.fartfix.logUtils.LogPrint;
import com.example.fartfix.ui.MainActivity;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FixDexTask extends AsyncTask<Object, Void, Void> {
    private static final String TAG = "FixDexTask";

    private String dexFilePathStr;
    private String binFilePathStr;
    private boolean delTriesFlag;
    private MainActivity mainActivity;

    @Override
    protected Void doInBackground(Object... objs) {
        dexFilePathStr = (String) objs[0];
        binFilePathStr = (String) objs[1];
        delTriesFlag = (boolean) objs[2];
        mainActivity = (MainActivity) objs[3];
        fixDexFile();
        return null;
    }

    private void fixDexFile() {
        try {
            RandomAccessFile dexFileStream = new RandomAccessFile(new File(dexFilePathStr), "rw");
            Map binFileMap = initBinFile();
            Dex dexFile = Dex.fromFile(dexFilePathStr);
            ArrayList<Dex.ClassDefItem> classDefItemsArrayList = dexFile.classDefs();
            for (Dex.ClassDefItem classDefItem : classDefItemsArrayList) {
                Dex.ClassDataItem classDataItem = classDefItem.classData();
                if (classDataItem != null) {
                    // virtualMethods
                    ArrayList<Dex.EncodedMethod> virtualMethodsArrayList = classDataItem.virtualMethods();
                    if (virtualMethodsArrayList != null) {
                        modifyMethods(dexFileStream, binFileMap, virtualMethodsArrayList);
                    }

                    // directMethods
                    ArrayList<Dex.EncodedMethod> directMethodArrayList = classDataItem.directMethods();
                    if (directMethodArrayList != null) {
                        modifyMethods(dexFileStream, binFileMap, directMethodArrayList);
                    }
                }


            }
            dexFileStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void modifyMethods(RandomAccessFile dexFileStream, Map binFileMap, ArrayList<Dex.EncodedMethod> encodedMethodsArrayList) throws IOException {
        int encodedMethodIdx = 0;
        long encodedMethodCodeOff = 0;
        for (int i = 0; i < encodedMethodsArrayList.size(); i++) {
            Dex.EncodedMethod encodedMethod = encodedMethodsArrayList.get(i);
            if (i == 0) {
                encodedMethodIdx = encodedMethod.methodIdxDiff().value();
            } else {
                encodedMethodIdx += encodedMethod.methodIdxDiff().value();
            }
            encodedMethodCodeOff = encodedMethod.codeOff().value();
            String inisCodeContent = (String) binFileMap.get(encodedMethodIdx + "");
            if (inisCodeContent != null) {
                String[] inisCodeContentArr = inisCodeContent.split(":");
                int inisCodeLen = Integer.parseInt(inisCodeContentArr[0]);
                String inisCodeBase64 = inisCodeContentArr[1];
                byte[] inisCodeSeg = new byte[inisCodeLen - 12];
                System.arraycopy(Base64.decode(inisCodeBase64, Base64.NO_WRAP), 12, inisCodeSeg, 0, inisCodeLen - 12);
                dexFileStream.seek(encodedMethodCodeOff + 12);
                byte[] origInisSeg = new byte[inisCodeLen - 12];
                dexFileStream.read(origInisSeg);
//                LogPrint.logd(TAG, "modifyMethods: orig inis base64:" + Base64.encodeToString(origInisSeg, Base64.NO_WRAP) + ", dump inis base64:" + Base64.encodeToString(inisCodeSeg, Base64.NO_WRAP));
                if (!Arrays.equals(origInisSeg, inisCodeSeg)) {
//                    LogPrint.logd(TAG, "modifyMethods: start fix dex encode method idx:" + encodedMethodIdx);
                    dexFileStream.seek(encodedMethodCodeOff + 12);
                    dexFileStream.write(inisCodeSeg);

                    // log
//                    dexFileStream.seek(encodedMethodCodeOff);
//                    byte[] modifyInis = new byte[inisCodeLen];
//                    dexFileStream.read(modifyInis);
//                    LogPrint.logd(TAG, "modifyMethods: modify inis base64:" + Base64.encodeToString(modifyInis, Base64.NO_WRAP));
                    // log

                    if (delTriesFlag) {
                        dexFileStream.seek(encodedMethodCodeOff + 6);
                        byte[] tryinfo = new byte[1];
                        dexFileStream.write(tryinfo);

                        // log
//                        dexFileStream.seek(encodedMethodCodeOff);
//                        modifyInis = new byte[inisCodeLen];
//                        dexFileStream.read(modifyInis);
//                        LogPrint.logd(TAG, "modifyMethods: modify tries info base64:" + Base64.encodeToString(modifyInis, Base64.NO_WRAP));
                        // log
                    }
                }
                // modify debug info
                dexFileStream.seek(encodedMethodCodeOff + 8);
                byte[] debuginfo = new byte[4];
                dexFileStream.write(debuginfo);

                // log
//                dexFileStream.seek(encodedMethodCodeOff);
//                byte[] modifyInis = new byte[inisCodeLen];
//                dexFileStream.read(modifyInis);
//                LogPrint.logd(TAG, "modifyMethods: modify debug info base64:" + Base64.encodeToString(modifyInis, Base64.NO_WRAP));
                // log
            }
        }
    }

    private Map initBinFile() {
        StringBuilder stringBuilder = new StringBuilder();
        Map<String, String> binFileMap = new HashMap();
        try {
            char[] content = new char[1024];
            BufferedReader bufferedReader = new BufferedReader(new FileReader(binFilePathStr));
            while (bufferedReader.read(content) != -1) {
                stringBuilder.append(content);
            }

            String contentStr = stringBuilder.toString();
            String[] inis_codes = contentStr.split(";");
            for (String inis_code : inis_codes) {
                String key = "";
                String value = "";
                Pattern pattern = Pattern.compile("method_idx:(\\d*)");
                Matcher matcher = pattern.matcher(inis_code);
                if (matcher.find()) {
                    key = matcher.group(1);
                }
                pattern = Pattern.compile("code_item_len:(\\d*)");
                matcher = pattern.matcher(inis_code);

                if (matcher.find()) {
                    value = matcher.group(1);
                }
                pattern = Pattern.compile("ins:(\\S*)\\}");
                matcher = pattern.matcher(inis_code);
                if (matcher.find()) {
                    value = value + ":" + matcher.group(1);
                }

                if (!key.equals("")) {
                    binFileMap.put(key, value);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return binFileMap;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        mainActivity.showFinishInProgressUI();
        Toast.makeText(mainActivity, "finish", Toast.LENGTH_SHORT).show();
    }
}
