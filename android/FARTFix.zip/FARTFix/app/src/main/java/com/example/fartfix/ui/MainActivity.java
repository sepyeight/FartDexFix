package com.example.fartfix.ui;

import android.os.AsyncTask;
import android.os.Bundle;

import com.example.fartfix.R;
import com.example.fartfix.tools.FixDexTask;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    /**
     * dex_file_path
     * bin_file_path
     * del_switch
     * start
     */
    private EditText dexFilePathET;
    private EditText binFilePathET;
    private Switch delSwitch;
    private Button startBtn;
    private String dexFilePathStr;
    private String binFilePathStr;
    private ProgressBar startingPB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
//        initTestData();
        initListener();
    }

    private void initTestData() {
        dexFilePathET.setText("/sdcard/00.dex");
        binFilePathET.setText("/sdcard/00.bin");
        delSwitch.setChecked(true);
    }

    private void initListener() {
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkArgs()){
                    start2Fix(dexFilePathStr, binFilePathStr, delSwitch.isChecked());
                }
            }
        });
    }

    private void start2Fix(String dexFilePath, String binFilePath, boolean delSwitchFlag) {
        //1. disable button and show progress bar
        showStartingInProgressUI();
        FixDexTask task = new FixDexTask();
        task.execute(dexFilePath, binFilePath, delSwitchFlag, this);
    }

    public void showFinishInProgressUI() {
        startBtn.setClickable(true);
        startingPB.setVisibility(View.GONE);
    }

    private void showStartingInProgressUI() {
        startBtn.setClickable(false);
        startingPB.setVisibility(View.VISIBLE);
    }

    private boolean checkArgs() {
        dexFilePathStr = dexFilePathET.getText().toString().trim();
        binFilePathStr = binFilePathET.getText().toString().trim();
        if(dexFilePathStr.length() !=0 && binFilePathStr.length() !=0){
            return true;
        }
        return false;
    }

    private void initView() {
        dexFilePathET = findViewById(R.id.dex_file_path_edittext);
        binFilePathET = findViewById(R.id.bin_file_path_edittext);
        delSwitch = findViewById(R.id.del_switch);
        startBtn = findViewById(R.id.start_button);
        startingPB = findViewById(R.id.starting_progressbar);
    }

}